const touchArea = document.getElementById('touch-area');
const replayButton = document.getElementById('replay-button');
const speedControl = document.getElementById('speed-control');
let touchMoves = [];
let speeds = [];

touchArea.addEventListener('touchstart', (event) => {
    touchMoves = []; // Reset the touch moves on new touch start
    speeds = []; // Reset speeds
    const touch = event.touches[0];
    touchMoves.push({ x: touch.clientX, y: touch.clientY, time: Date.now() });
});

touchArea.addEventListener('touchmove', (event) => {
    const touch = event.touches[0];
    const lastMove = touchMoves[touchMoves.length - 1];
    const currentTime = Date.now();
    const deltaTime = currentTime - lastMove.time;
    const deltaX = touch.clientX - lastMove.x;
    const deltaY = touch.clientY - lastMove.y;
    const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    const speed = distance / deltaTime;
    speeds.push(speed);

    touchMoves.push({ x: touch.clientX, y: touch.clientY, time: currentTime });
});

touchArea.addEventListener('touchend', (event) => {
    const touch = event.changedTouches[0];
    touchMoves.push({ x: touch.clientX, y: touch.clientY, time: Date.now() });
});

replayButton.addEventListener('click', () => {
    if (touchMoves.length === 0) return;

    let index = 0;
    const startTime = touchMoves[0].time;
    const playbackSpeed = parseFloat(speedControl.value);

    const moveIndicator = document.createElement('div');
    moveIndicator.style.position = 'absolute';
    moveIndicator.style.width = '20px';
    moveIndicator.style.height = '20px';
    moveIndicator.style.backgroundColor = 'red';
    moveIndicator.style.borderRadius = '50%';
    document.body.appendChild(moveIndicator);

    const replayMoves = () => {
        if (index >= touchMoves.length) {
            moveIndicator.remove();
            return;
        }

        const { x, y, time } = touchMoves[index];
        moveIndicator.style.left = `${x}px`;
        moveIndicator.style.top = `${y}px`;

        const nextIndex = index + 1;
        if (nextIndex < touchMoves.length) {
            const nextTime = touchMoves[nextIndex].time;
            const speed = speeds[index - 1] || 1;
            setTimeout(replayMoves, ((nextTime - time) / speed) / playbackSpeed);
        }

        index = nextIndex;
    };

    replayMoves();
});